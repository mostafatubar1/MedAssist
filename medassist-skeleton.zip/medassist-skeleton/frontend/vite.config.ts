import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = fileURLToPath(new URL(".", import.meta.url));

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@shared": path.resolve(rootDir, "../shared/types") },
  },
  server: {
    host: "0.0.0.0",
    fs: { allow: [path.resolve(rootDir, "..")] },
  },
});
