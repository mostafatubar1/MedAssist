# patient_memory tests

Owner: Omar. Add both `test_*_validation.py` and `test_*_defects.py` as this domain is implemented. Keep validation cases traceable to SRS requirement IDs.
